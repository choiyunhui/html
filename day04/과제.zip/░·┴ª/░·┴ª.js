var heading1 = document.querySelector('#heading1');  //id가 헤딩인 문서를 선택하겠다.
heading1.onclick = function(){ //그 단어를 선택했을 시 //무의미 함수는 지금만 사용하고 사용하지 않을 때만 활용
  heading1.style.color = "red";
}
  var heading2 = document.querySelector('#heading2');  //id가 헤딩인 문서를 선택하겠다.
heading2.onclick = function(){ //그 단어를 선택했을 시 //무의미 함수는 지금만 사용하고 사용하지 않을 때만 활용
  heading2.style.color = "blue";
}